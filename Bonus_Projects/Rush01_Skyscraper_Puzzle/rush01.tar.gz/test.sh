#!/bin/bash

FILE=tmp.txt

if [ "$#" -ne 1 ]; then
    echo "Please provide path to user executable."
	exit
fi

# Valid
echo "Running user executable against valid inputs..."
echo "" > ${FILE}
while IFS="" read -r p || [ -n "$p" ]
do
	./$1 "$p" >> ${FILE}
done < inputs.txt
tail -n +2 "${FILE}" > ${FILE}.tmp
mv ${FILE}.tmp ${FILE}

printf "Comparing...\n"
DIFF=$(diff ${FILE} grids.txt)
if [ "$DIFF" == "" ]; then
	echo "[SUCCESS] You passed :)"
else
    echo "[FAIL] Ouput not correct :("
	echo ""
	echo $DIFF
fi

# Invalid
printf "Running user executable against invalid inputs...\n"
while IFS="" read -r p || [ -n "$p" ]
do
	OUT=$(./$1 "$p")
	printf "Input: \"${p}\"\nOutput:\n${OUT}\n\n"
done < invalid.txt